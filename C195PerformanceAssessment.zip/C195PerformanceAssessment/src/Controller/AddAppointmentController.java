/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.JDBC;
import Model.Appointments;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Tomy Li He
 */
public class AddAppointmentController{
    Stage stage;
    Parent scene;
    
    @FXML
    private TextField CustomerIDField;
    @FXML
    private TextField TitleField;
    @FXML
    private TextField TypeField;
    @FXML
    private TextField UserIDField;
    @FXML
    private DatePicker StartDateField;
    @FXML
    private DatePicker EndDateField;
    @FXML
    private TextField StartHourField;
    @FXML
    private TextField StartMinuteField;
    @FXML
    private TextField EndHourField;
    @FXML
    private TextField EndMinuteField;
    @FXML
    private TextField LocationField;
    @FXML
    private TextField DescriptionField;
    @FXML
    private TextField ContactIDField;
    
    private final DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss");
    @FXML
    private void closeHandler(ActionEvent event) throws IOException{
        scene = FXMLLoader.load(getClass().getResource("/View/MainMenu.fxml"));
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }
    
    @FXML
    private void saveHandler(ActionEvent event) throws IOException, SQLException {
        String startHourStr = "";
        String startMinuteStr = "";
        String endHourStr = "";
        String endMinuteStr = "";
        int startHour = 0;
        int startMinute = 0;
        int endHour= 0;
        int endMinute = 0;
        LocalTime startTime = LocalTime.now();
        LocalTime endTime = LocalTime.now();
        LocalTime midnight = LocalTime.MIDNIGHT;
        
        try{
            startHour = Integer.parseInt(StartHourField.getText());
            startMinute = Integer.parseInt(StartMinuteField.getText());
            endHour= Integer.parseInt(EndHourField.getText());
            endMinute = Integer.parseInt(EndMinuteField.getText());     
            
            if(startHour < 10) {
                startHourStr = "0" + Integer.toString(startHour);
            }
            else {
                startHourStr = StartHourField.getText();
            }
            if(startMinute < 10) {
                startMinuteStr = "0" + Integer.toString(startMinute);
            }
            else {
                startMinuteStr = StartMinuteField.getText();
            }

            if(endHour < 10) {
                endHourStr = "0" + Integer.toString(endHour);
            }
            else {
                endHourStr = EndHourField.getText();
            }
            if(endMinute < 10) {
                endMinuteStr = "0" + Integer.toString(endMinute);
            }
            else {
                endMinuteStr = EndMinuteField.getText();
            }    
        }catch(Exception e){
            System.out.println("Exception error: " + e.getMessage());
        }
             
        
        try{
              
            String userStartInput = startHourStr + ":" + startMinuteStr + ":00";
            String userEndInput = endHourStr + ":" + endMinuteStr + ":00";
            
            startTime = LocalTime.parse(userStartInput, timeFormat);
            endTime = LocalTime.parse(userEndInput, timeFormat);  
            
        }catch(Exception e){
            System.out.println("Exception error: " + e.getMessage());
        }
        
        if(CustomerIDField.getText().isEmpty() || TitleField.getText().isEmpty() || TypeField.getText().isEmpty() || UserIDField.getText().isEmpty() || StartHourField.getText().isEmpty() 
                                                                    || StartMinuteField.getText().isEmpty() || EndHourField.getText().isEmpty() || EndMinuteField.getText().isEmpty() 
                                                                    || StartDateField.getValue() == null || EndDateField.getValue() == null || LocationField.getText().isEmpty() || DescriptionField.getText().isEmpty() 
                                                                    || ContactIDField.getText().isEmpty() ){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.initModality(Modality.NONE);
            alert.setTitle("Missing Information Fields");
            alert.setHeaderText("Fill All Required Fields");
            Optional<ButtonType> showAndWait = alert.showAndWait();          
           
        }
        //Check to see if appointment is within business hours              
        if(startHour > 23 || startMinute > 59 || endHour > 23 || endMinute > 59){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.initModality(Modality.NONE);
            alert.setTitle("Invalid Times entered");
            alert.setHeaderText("Please enter valid time values in the 24H format");
            Optional<ButtonType> showAndWait = alert.showAndWait();
        }
            
        if(startTime.isBefore(midnight.plusHours(8)) || startTime.isAfter(midnight.minusHours(2)) || endTime.isBefore(midnight.plusHours(8)) || endTime.isAfter(midnight.minusHours(2))){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.initModality(Modality.NONE);
            alert.setTitle("Invalid appointment time");
            alert.setHeaderText("Please enter an appointment time within the business hours of 8:00AM to 10:00 PM EST");
            Optional<ButtonType> showAndWait = alert.showAndWait();         
        }
        
        else{
            //convert into string
            String startDateTimeStr = StartDateField.getValue().toString() + " " + startHourStr + ":" + startMinuteStr + ":00";
            String endDateTimeStr = EndDateField.getValue().toString() + " " + endHourStr + ":" + endMinuteStr + ":00";
            String startDateStr = StartDateField.getValue().toString();
            String endDateStr = EndDateField.getValue().toString();
            
            DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            //Converts appointment time string into localdatetime var
            LocalDateTime startDateTime = LocalDateTime.parse(startDateTimeStr, dateTimeFormat);
            LocalDateTime endDateTime = LocalDateTime.parse(endDateTimeStr, dateTimeFormat);
            LocalDate startDate = LocalDate.parse(startDateStr, dateFormat);
            LocalDate endDate = LocalDate.parse(endDateStr, dateFormat);
            
            //UTC time zone and current user time zone
            ZoneId userZone = ZoneOffset.systemDefault();           
            
            //Converts appointment time input into user's time zone
            ZonedDateTime userZoneStartTime = startDateTime.atZone(userZone);
            ZonedDateTime userZoneEndTime = endDateTime.atZone(userZone);
            
            //Convert appointment time input into UTC 
            ZonedDateTime utcStartTime = userZoneStartTime.withZoneSameInstant(ZoneOffset.UTC);
            ZonedDateTime utcEndTime = userZoneEndTime.withZoneSameInstant(ZoneOffset.UTC);
            
            //Convert back store in DB and appointment view
            
            startDateTime = utcStartTime.toLocalDateTime();
            endDateTime = utcEndTime.toLocalDateTime();
            
            Timestamp tsStart = Timestamp.valueOf(startDateTime);
            Timestamp tsEnd = Timestamp.valueOf(endDateTime);
                  
            
            try{
                if(userZoneStartTime.isAfter(userZoneEndTime)){
                    throw new ArithmeticException("Appointment start time cannot be after end time");
                }else{
                    if(!startDate.isEqual(endDate)){
                        throw new ArithmeticException("Appointment exceeds business hours on the same day");
                    }else{
                        
                        Statement dbc_start = JDBC.getConnection().createStatement();
                        Statement dbc_end = JDBC.getConnection().createStatement();

                        //Start and end strings need the UTC datetime
                        String queryStartDate = "SELECT * FROM appointments WHERE Start BETWEEN '" + tsStart + "' AND '" + tsEnd + "'";
                        String queryEndDate = "SELECT * FROM appointments WHERE End BETWEEN '" + tsStart + "' AND '" + tsEnd + "'";

                        ResultSet rs_start = dbc_start.executeQuery(queryStartDate);
                        ResultSet rs_end = dbc_end.executeQuery(queryEndDate);                                            
                        
                        
                        if(rs_start.getRow() > 0 || rs_end.getRow() > 0) {
                            throw new ArithmeticException("Appointment exists during this time frame. Please choose another time frame for your appointment");
                        }else{
                            
                            int appointmentID = 1;
                            
                            Statement dbConnection = JDBC.getConnection().createStatement();
                            ResultSet rs = dbConnection.executeQuery("SELECT MAX(Appointment_ID) FROM appointments");
                                                 
                            if(rs.next()){
                                appointmentID = rs.getInt(1) + 1;                                                            
                            }
                            
                            
                            String insertQuery = "INSERT INTO appointments VALUES (" + appointmentID + ",'" + TitleField.getText() + "','" + DescriptionField.getText() + "','" + LocationField.getText() + "','" 
                                                                                    + TypeField.getText() + "','" + tsStart + "','" + tsEnd + "','2022-06-04 00:00:00','test','2022-06-04 00:00:00','test','" + CustomerIDField.getText()
                                                                                    + "','" + UserIDField.getText() + "'," + ContactIDField.getText() + ")";
                            
                            dbConnection.executeUpdate(insertQuery);
                            
                            Appointments newAppointment = new Appointments(appointmentID, TitleField.getText(), DescriptionField.getText(), LocationField.getText(), TypeField.getText(), userZoneStartTime, userZoneEndTime, Integer.parseInt(CustomerIDField.getText()),
                                                                            Integer.parseInt(UserIDField.getText()), Integer.parseInt(ContactIDField.getText()));
                            
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.initModality(Modality.NONE);
                            alert.setTitle("Appointment Added");
                            alert.setHeaderText("Appointment successfully added");
                            alert.showAndWait();
                            
                            scene = FXMLLoader.load(getClass().getResource("/View/MainMenu.fxml"));
                            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
                            stage.setScene(new Scene((Parent) scene));
                            stage.show();
                        }
                        
                    }
                }
            } catch(SQLException e){
                System.out.println("SQLException error: " + e.getMessage());
            }
        }
    }
}
